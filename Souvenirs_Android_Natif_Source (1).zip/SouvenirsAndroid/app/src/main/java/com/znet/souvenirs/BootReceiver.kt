package com.znet.souvenirs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent?){
        if(intent?.action==Intent.ACTION_BOOT_COMPLETED){
            val alarm=context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val pi=android.app.PendingIntent.getBroadcast(context,44,Intent(context,ReminderReceiver::class.java),android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val cal=java.util.Calendar.getInstance().apply{add(java.util.Calendar.MINUTE,1)}
            alarm.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP,cal.timeInMillis,android.app.AlarmManager.INTERVAL_DAY,pi)
        }
    }
}
