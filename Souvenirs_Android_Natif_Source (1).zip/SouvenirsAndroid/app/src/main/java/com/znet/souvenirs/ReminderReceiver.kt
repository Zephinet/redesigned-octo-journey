package com.znet.souvenirs

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

class ReminderReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent?){
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return
        val prefs=context.getSharedPreferences("souvenirs",Context.MODE_PRIVATE)
        val arr=JSONArray(prefs.getString("people","[]"))
        val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US);val now=Calendar.getInstance()
        val today=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i);val birthday=o.optString("birthday");val name=o.optString("name")
            try{
                val d=Calendar.getInstance();d.time=fmt.parse(birthday)!!;d.set(Calendar.YEAR,now.get(Calendar.YEAR));d.set(Calendar.HOUR_OF_DAY,0);d.set(Calendar.MINUTE,0);d.set(Calendar.SECOND,0);d.set(Calendar.MILLISECOND,0)
                if(d.before(today))d.add(Calendar.YEAR,1)
                val days=((d.timeInMillis-today.timeInMillis)/86400000L).toInt()
                if(days==2||days==0){
                    val year=now.get(Calendar.YEAR);val key="notified_${o.optString("id")}_${year}_$days"
                    if(!prefs.getBoolean(key,false)){
                        val title=if(days==0)"🎂 Anniversaire aujourd’hui !" else "🔔 Anniversaire dans 2 jours"
                        val body=if(days==0)"Pensez à souhaiter un joyeux anniversaire à $name." else "L’anniversaire de $name approche."
                        val n=Notification.Builder(context,"birthdays").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).build()
                        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((o.optString("id").hashCode() and 0x7fffffff),n)
                        prefs.edit().putBoolean(key,true).apply()
                    }
                }
            }catch(_:Exception){}
        }
    }
}
