package com.znet.souvenirs

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Person(val id:String,val name:String,val birthday:String,val phone:String,val note:String,val message:String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("souvenirs", MODE_PRIVATE) }
    private val people = mutableListOf<Person>()
    private lateinit var list: LinearLayout
    private lateinit var root: LinearLayout
    private val purple = Color.rgb(103, 80, 220)
    private val ink = Color.rgb(26, 31, 51)
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPeople()
        makeChannel()
        scheduleDailyCheck()
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float,bold:Boolean=false,color:Int=ink):TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold)setTypeface(null,android.graphics.Typeface.BOLD)
    }
    private fun button(s:String, action:()->Unit):Button = Button(this).apply {
        text=s; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(purple)
        setOnClickListener { action() }
    }
    private fun buildUi(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(246,247,252))}
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(20))}
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(22),dp(20),dp(22));background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.rgb(35,29,77));cornerRadius=dp(24).toFloat()}}
        hero.addView(text("✦ SOUVENIRS",20f,true,Color.WHITE))
        hero.addView(text("Les dates importantes.\nJamais oubliées.",28f,true,Color.WHITE).apply{setPadding(0,dp(20),0,dp(8))})
        hero.addView(text("Vos anniversaires, vos attentions.",14f,false,Color.rgb(220,215,245)))
        content.addView(hero)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(0,dp(14),0,dp(8))}
        row.addView(button("＋ Ajouter",::showAddDialog),LinearLayout.LayoutParams(0,dp(52),1f))
        row.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
        row.addView(button("Importer contact",::pickContact),LinearLayout.LayoutParams(0,dp(52),1f))
        content.addView(row)
        content.addView(text("PROCHAINS ANNIVERSAIRES",13f,true,purple).apply{setPadding(dp(2),dp(16),0,dp(10))})
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        content.addView(list)
        content.addView(text("Rappel : les notifications arrivent deux jours avant et le jour J. WhatsApp s’ouvre avec un message prêt à envoyer ; il faut confirmer l’envoi dans WhatsApp.",12f,false,Color.DKGRAY).apply{setPadding(dp(8),dp(18),dp(8),dp(8))})
        scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val footer=TextView(this).apply{text="Données enregistrées sur ce téléphone  •  ⚙ Message par défaut";textSize=12f;gravity=Gravity.CENTER;setPadding(dp(12),dp(14),dp(12),dp(14));setTextColor(purple);setOnClickListener{editDefaultMessage()}}
        root.addView(footer)
        setContentView(root); render()
    }
    private fun loadPeople(){
        people.clear()
        val arr=JSONArray(prefs.getString("people","[]"))
        for(i in 0 until arr.length()){val o=arr.getJSONObject(i);people.add(Person(o.optString("id"),o.optString("name"),o.optString("birthday"),o.optString("phone"),o.optString("note"),o.optString("message")))}
    }
    private fun savePeople(){
        val arr=JSONArray()
        people.forEach{p->arr.put(JSONObject().put("id",p.id).put("name",p.name).put("birthday",p.birthday).put("phone",p.phone).put("note",p.note).put("message",p.message))}
        prefs.edit().putString("people",arr.toString()).apply();render();scheduleDailyCheck()
    }
    private fun daysUntil(birthday:String):Int { return try {
        val d=dateFmt.parse(birthday)!!; val cal=Calendar.getInstance();val today=Calendar.getInstance()
        cal.time=d;cal.set(Calendar.YEAR,today.get(Calendar.YEAR));cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0)
        today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0)
        if(cal.before(today))cal.add(Calendar.YEAR,1)
        ((cal.timeInMillis-today.timeInMillis)/86400000L).toInt()
    }catch(_:Exception){999} }
    private fun render(){
        if(!::list.isInitialized)return
        list.removeAllViews()
        val sorted=people.sortedBy{daysUntil(it.birthday)}
        if(sorted.isEmpty()){list.addView(text("Aucun contact pour le moment.\nAjoutez une personne pour commencer.",15f,false,Color.GRAY).apply{setPadding(dp(12),dp(25),dp(12),dp(25))});return}
        sorted.forEach { p ->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=dp(16).toFloat();setStroke(dp(1),Color.rgb(231,232,242))};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)}}
            val days=daysUntil(p.birthday);val whenText=when(days){0->"Aujourd’hui 🎂";1->"Demain";else->"Dans $days jours"}
            card.addView(text(p.name,17f,true))
            card.addView(text("${p.birthday}  •  $whenText",13f,false,purple).apply{setPadding(0,dp(5),0,dp(5))})
            if(p.note.isNotBlank())card.addView(text(p.note,12f,false,Color.GRAY))
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            actions.addView(button("Modifier", {showEditDialog(p)}),LinearLayout.LayoutParams(0,dp(44),1f))
            actions.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
            actions.addView(button("WhatsApp ↗", {sendWhatsApp(p)}),LinearLayout.LayoutParams(0,dp(44),1f))
            card.addView(actions);list.addView(card)
        }
    }
    private fun showAddDialog(){ showPersonDialog(null) }
    private fun showEditDialog(p:Person){ showPersonDialog(p) }
    private fun showPersonDialog(old:Person?){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(8),dp(22),dp(4))}
        fun field(label:String,value:String=""):EditText{box.addView(text(label,12f,true,Color.DKGRAY));return EditText(this).apply{setText(value);hint=label;box.addView(this)}}
        val name=field("Nom complet",old?.name.orEmpty())
        val birthday=field("Date de naissance (AAAA-MM-JJ)",old?.birthday.orEmpty())
        val phone=field("Téléphone avec indicatif international",old?.phone.orEmpty())
        val note=field("Relation / note",old?.note.orEmpty())
        val msg=field("Message personnalisé (facultatif)",old?.message.orEmpty())
        AlertDialog.Builder(this).setTitle(if(old==null)"Ajouter un anniversaire" else "Modifier le contact").setView(box)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->
                val n=name.text.toString().trim();val b=birthday.text.toString().trim()
                if(n.isBlank()||!b.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))){toast("Nom et date AAAA-MM-JJ obligatoires");return@setPositiveButton}
                val person=Person(old?.id?:UUID.randomUUID().toString(),n,b,phone.text.toString().trim(),note.text.toString().trim(),msg.text.toString().trim())
                if(old==null)people.add(person) else {val ix=people.indexOfFirst{it.id==old.id};if(ix>=0)people[ix]=person}
                savePeople();toast("Contact enregistré")
            }.show()
    }
    private fun pickContact(){
        try{startActivityForResult(Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI),101)}
        catch(_:Exception){toast("Le répertoire est indisponible")}
    }
    @Deprecated("legacy contact picker callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101&&resultCode==RESULT_OK&&data?.data!=null){
            var name="";var phone=""
            val c=contentResolver.query(data.data!!, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER),null,null,null)
            c?.use{if(it.moveToFirst()){name=it.getString(0)?: "";phone=it.getString(1)?: ""}}
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0)}
            val birthday=EditText(this).apply{hint="Date de naissance (AAAA-MM-JJ)"};box.addView(birthday)
            AlertDialog.Builder(this).setTitle("Ajouter $name").setMessage("Contact importé du répertoire. Ajoutez sa date de naissance.")
                .setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->
                    val b=birthday.text.toString().trim()
                    if(b.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))){people.add(Person(UUID.randomUUID().toString(),name,b,phone,"",""));savePeople()}else toast("Date invalide. Format : AAAA-MM-JJ")
                }.show()
        }
    }
    private fun sendWhatsApp(p:Person){
        if(p.phone.isBlank()){toast("Ajoutez d’abord le numéro de téléphone");return}
        val first=p.name.split(" ").firstOrNull()?:p.name
        val template=p.message.ifBlank{prefs.getString("message","Joyeux anniversaire {prenom} ! 🎉🎂 Je te souhaite bonheur, santé et réussite dans tous tes projets.")!!}
        val msg=template.replace("{prenom}",first).replace("{nom}",p.name)
        val number=p.phone.filter{it.isDigit()}
        val uri=Uri.parse("https://wa.me/$number?text="+Uri.encode(msg))
        try{startActivity(Intent(Intent.ACTION_VIEW,uri))}catch(_:Exception){toast("WhatsApp ou un navigateur est nécessaire")}
    }
    private fun editDefaultMessage(){
        val input=EditText(this).apply{setText(prefs.getString("message","Joyeux anniversaire {prenom} ! 🎉🎂 Je te souhaite bonheur, santé et réussite dans tous tes projets."));minLines=4}
        AlertDialog.Builder(this).setTitle("Message par défaut").setMessage("Utilisez {prenom} et {nom} comme variables.").setView(input)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer"){_,_->prefs.edit().putString("message",input.text.toString()).apply();toast("Message enregistré")}.show()
    }
    private fun makeChannel(){
        if(Build.VERSION.SDK_INT>=26){val manager=getSystemService(NotificationManager::class.java);manager.createNotificationChannel(NotificationChannel("birthdays","Rappels d’anniversaire",NotificationManager.IMPORTANCE_HIGH).apply{description="Rappels deux jours avant et le jour J"})}
    }
    private fun scheduleDailyCheck(){
        val intent=Intent(this,ReminderReceiver::class.java)
        val pi=PendingIntent.getBroadcast(this,44,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm=getSystemService(ALARM_SERVICE) as AlarmManager
        val cal=Calendar.getInstance().apply{add(Calendar.MINUTE,1);set(Calendar.SECOND,0)}
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
