# Souvenirs — version Android native (source)

Ce projet Android natif Kotlin est conçu pour Android 8.0+ (API 26+). Il fournit une interface native, l'enregistrement local des contacts suivis, l'import d'une fiche du répertoire Android via le sélecteur système, la personnalisation du message, l'ouverture de WhatsApp avec le texte prérempli et des notifications quotidiennes pour les anniversaires à J-2 et J.

## Important
Ce livrable est le **projet source Android**, pas un APK déjà compilé. L'environnement de génération disponible ici ne contient ni Android SDK ni Gradle, donc je ne peux pas compiler et tester un APK installable directement dans cette session. Le workflow GitHub Actions fourni compile un APK debug lorsque le projet est poussé dans un dépôt GitHub puis lancé via Actions. L'APK généré se récupère dans les *Artifacts* de l'exécution.

## Compiler avec Android Studio
1. Installer Android Studio et son SDK Android 35.
2. Ouvrir le dossier du projet dans Android Studio.
3. Laisser Gradle synchroniser puis choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Le fichier debug se trouve normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

## Compiler dans GitHub
1. Créer un dépôt GitHub et y envoyer le contenu de cette archive.
2. Ouvrir l'onglet Actions et lancer **Build Android APK**.
3. Télécharger l'artifact `Souvenirs-debug-apk` de l'exécution terminée.

## Limites / précautions
- Les rappels sont programmés avec une alarme Android quotidienne inexacte. Les fabricants peuvent retarder les alarmes selon l'optimisation batterie ; autoriser les notifications et, si nécessaire, exclure Souvenirs de l'optimisation batterie.
- Le rappel quotidien est rétabli au redémarrage du téléphone.
- WhatsApp exige une confirmation manuelle de l'envoi : l'app prépare le message mais ne l'envoie pas silencieusement.
- L'import utilise le sélecteur de contacts Android et n'aspire pas tout le carnet d'adresses.
- Les données restent dans les préférences locales de l'application. Désinstaller l'app efface ces données.
- Pour la production, il est recommandé d'ajouter une base Room, une sauvegarde/export, un sélecteur de date graphique et des tests sur appareils réels.
